<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container" style="margin-top: 30px;">
    <form method="post" action="<?php echo e(route('category.store')); ?>">
        <?php echo e(csrf_field()); ?>


        <?php if(@session('response')): ?>
        <div class="alert alert-dismissible alert-success">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>
                <?php echo e(@session('response')); ?>

            </strong>
        </div>
        <?php endif; ?>

        <fieldset>
            <legend>Legend</legend>
            <div class="form-group row">
                <label for="categoryName" class="col-sm-2 col-form-label">Name</label>
                <div class="col-sm-10">
                    <input type="text" name="categoryName" class="form-control" id="categoryName"
                        placeholder="Enter Category Name" />

                    <?php if($errors->has('categoryName')): ?>
                    <small class="form-text invalid-feedback">
                        <?php echo e($errors->first('categoryName')); ?>

                    </small>
                    <?php endif; ?>

                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </fieldset>
    </form>
</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>