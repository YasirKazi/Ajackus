<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(@session('message')): ?>
<div class="alert alert-dismissible alert-success">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>
        <?php echo e(@session('message')); ?>

    </strong>
</div>
<?php endif; ?>
<div class="container" style="margin-top: 30px;">

    <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">Sr.</th>
                <th scope="col">Customer Name</th>
                <th scope="col">Mobile No.</th>
                <th scope="col">Address Type</th>
                <th scope="col">City</th>
                <th scope="col">Order Total</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderObj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row">
                    <?php echo e($orderObj->id); ?>

                </th>
                <td>
                    <strong><?php echo e($orderObj->name); ?></strong>
                </td>
                <td>
                    <strong><?php echo e($orderObj->mobile); ?></strong>
                </td>
                <td>
                    <strong><?php echo e($orderObj->address_type); ?></strong>
                </td>
                <td>
                    <strong><?php echo e($orderObj->city); ?></strong>
                </td>
                <td>
                    <strong>&#x20b9; <?php echo e($orderObj->order_total); ?></strong>
                </td>
                <td>
                    <a href="<?php echo e('/orders/'.$orderObj->id); ?>" class="btn btn-sm btn-primary">Show Details</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>