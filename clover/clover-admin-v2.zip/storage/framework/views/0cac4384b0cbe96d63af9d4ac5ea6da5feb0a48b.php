<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(@session('message')): ?>
<div class="alert alert-dismissible alert-success">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>
        <?php echo e(@session('message')); ?>

    </strong>
</div>
<?php endif; ?>
<div class="container" style="margin-top: 30px;">
    <div class="text-right">
        <a href="product/create" class="btn btn-primary">Add New Product</a>
        <br />
        <br />
    </div>
    <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">Sr.</th>
                <th scope="col">Product Name</th>
                <th scope="col">Category</th>
                <th scope="col">Price</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productObj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row">
                    <?php echo e($productObj->id); ?>

                </th>
                <td>
                    <strong><?php echo e($productObj->name); ?></strong>
                </td>
                <td>
                    <strong><?php echo e($productObj->category); ?></strong>
                </td>
                <td>
                    <strong><?php echo e($productObj->price); ?></strong>
                </td>
                <td>
                    <a href="<?php echo e('/product/'.$productObj->id); ?>" class="btn btn-sm btn-secondary">Show Details</a>
                    &nbsp;&nbsp;
                    <a href="<?php echo e('/product/'.$productObj->id.'/edit'); ?>" class="btn btn-sm btn-primary">Edit</a>
                    &nbsp;&nbsp;
                    <form class="form-group" style="display: inline;" action="<?php echo e('/product/'.$productObj->id); ?>"
                        method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" class="btn btn-sm btn-danger">Delete</a>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>