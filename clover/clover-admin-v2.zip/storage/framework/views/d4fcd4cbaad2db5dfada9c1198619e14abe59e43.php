<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container" style="margin-top: 30px;">
    <form method="post" action="/category/<?php echo $__env->yieldContent('editId'); ?>">
        <?php echo e(csrf_field()); ?>


        <?php $__env->startSection('editMethod'); ?>
        <?php echo $__env->yieldSection(); ?>

        <?php if(@session('response')): ?>
        <div class="alert alert-dismissible alert-success">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>
                <?php echo e(@session('response')); ?>

            </strong>
        </div>
        <?php endif; ?>

        <?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-dismissible alert-primary">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong><?php echo e($error); ?></strong>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <fieldset>
            <legend>Category</legend>
            <div class="form-group row">
                <label for="categoryName" class="col-sm-2 col-form-label">Name</label>
                <div class="col-sm-10">
                    <input type="text" name="name" class="form-control" id="categoryName"
                        placeholder="Enter Category Name" value="<?php echo $__env->yieldContent('editName'); ?>" />

                    <?php if($errors->has('categoryName')): ?>
                    <small class="form-text invalid-feedback">
                        <?php echo e($errors->first('categoryName')); ?>

                    </small>
                    <?php endif; ?>

                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            &nbsp;&nbsp;&nbsp;
            <a href="/category" class="btn btn-warning">Exit</a>
        </fieldset>
    </form>
</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>