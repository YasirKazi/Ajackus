<?php $__env->startSection('editId', $item->id); ?>
<?php $__env->startSection('editName', $item->name); ?>
<?php $__env->startSection('editDescription', $item->description); ?>
<?php $__env->startSection('editPrice', $item->price); ?>
<?php $__env->startSection('editImgUrl', $item->image_url); ?>
<?php $__env->startSection('editImgUrl', $item->image_url); ?>
<?php $__env->startSection('editCategoryId', $categoryData[0]->id); ?>
<?php $__env->startSection('editCategoryName', $categoryData[0]->name); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo e(method_field('PUT')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('product.createProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>