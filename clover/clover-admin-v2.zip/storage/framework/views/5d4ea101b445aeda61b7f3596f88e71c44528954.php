<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container" style="margin-top: 30px;">
    <form method="post" action="/product/<?php echo $__env->yieldContent('editId'); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


        <?php $__env->startSection('editMethod'); ?>
        <?php echo $__env->yieldSection(); ?>

        <?php if(@session('response')): ?>
        <div class="alert alert-dismissible alert-success">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>
                <?php echo e(@session('response')); ?>

            </strong>
        </div>
        <?php endif; ?>

        <?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-dismissible alert-primary">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong><?php echo e($error); ?></strong>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <fieldset>
            <legend>Product</legend>
            <div class="form-group row">
                <label for="productName" class="col-sm-2 col-form-label">Name</label>
                <div class="col-sm-10">
                    <input type="text" name="name" class="form-control" id="productName"
                        placeholder="Enter Product Name" value="<?php echo $__env->yieldContent('editName'); ?>" />

                    <?php if($errors->has('productName')): ?>
                    <small class="form-text invalid-feedback">
                        <?php echo e($errors->first('productName')); ?>

                    </small>
                    <?php endif; ?>

                </div>
            </div>
            <div class="form-group row">
                <label for="categoryName" class="col-sm-2 col-form-label">Category</label>
                <div class="col-sm-10">
                    <select name="category" class="form-control" id="categoryName">
                        <option value="<?php echo $__env->yieldContent('editCategoryId'); ?>"> <?php echo $__env->yieldContent('editCategoryName'); ?> </option>

                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryObj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoryObj->id); ?>"><?php echo e($categoryObj->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                    <?php if($errors->has('category')): ?>
                    <small class="form-text invalid-feedback">
                        <?php echo e($errors->first('category')); ?>

                    </small>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="description" class="col-sm-2 col-form-label">Description</label>
                <div class="col-sm-10">
                    <textarea name="description" class="form-control" id="description" placeholder="Enter Description"
                        rows="5">
                        <?php echo $__env->yieldContent('editDescription'); ?>
                    </textarea>

                    <?php if($errors->has('description')): ?>
                    <small class="form-text invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </small>
                    <?php endif; ?>

                </div>
            </div>
            <div class="form-group row">
                <label for="price" class="col-sm-2 col-form-label">Price</label>
                <div class="col-sm-10">
                    <input type="text" name="price" class="form-control" id="price" placeholder="Enter Price"
                        value="<?php echo $__env->yieldContent('editPrice'); ?>" />

                    <?php if($errors->has('price')): ?>
                    <small class="form-text invalid-feedback">
                        <?php echo e($errors->first('price')); ?>

                    </small>
                    <?php endif; ?>

                </div>
            </div>
            <div class="form-group">
                <label for="exampleInputFile">File input</label>
                <input type="file" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp"
                    name="image_url">
                <small id="fileHelp" class="form-text text-muted">Image should not be bigger than
                    <strong>20kb</strong></small>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            &nbsp;&nbsp;&nbsp;
            <a href="/product" class="btn btn-warning">Exit</a>
        </fieldset>
    </form>
</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>