<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container" style="margin-top: 30px;">
    <div class="card text-white bg-dark mb-3" style="max-width: 20rem;">
        <div class="card-header">Order Details</div>
        <div class="card-body">
            <h4 class="card-title"><?php echo e($item->name); ?></h4>
            <p>
                Order Total - &#x20b9; <?php echo e($item->order_total); ?>

            </p>
            <p>
                Mobile - <?php echo e($item->mobile); ?>

            </p>
            <p>
                Landmark - <?php echo e($item->landmark); ?>

            </p>
            <p>
                City - <?php echo e($item->city); ?>

            </p>
            <p>
                Address Type - <?php echo e($item->address_type); ?>

            </p>
            <div>
                <a href="/orders" class="btn btn-warning">Exit</a> &nbsp;&nbsp;
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>