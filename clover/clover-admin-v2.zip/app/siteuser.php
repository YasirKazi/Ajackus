<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class siteuser extends Model
{
    //
}
