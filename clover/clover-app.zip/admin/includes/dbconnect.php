<?php
    ob_start();
    $dbConnect = mysqli_connect("localhost","root","","clover_db");
?>